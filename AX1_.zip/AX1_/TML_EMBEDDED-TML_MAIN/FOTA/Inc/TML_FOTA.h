/*
 * TML_FOTA.h
 *
 *  Created on: Apr 23, 2024
 *      Author: 91944
 */

#ifndef TML_FOTA_H_
#define TML_FOTA_H_

#include "main.h"


void Config_Sectorupdate();
void WriteF_SKey();
void ReadF_Loc();
void WriteF_CKey();
void WriteF_AppLoc() ;





#endif /* TML_FOTA_H_ */
