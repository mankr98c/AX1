/*
 * gpio_handler.c
 *
 *  Created on: May 9, 2024
 *      Author: 91944
 */

#include"gpio_handler.h"
ADC_HandleTypeDef *evbSense,*ivbSense;
#define REFERANCE_VOLTAGE 11
#define INTERNAL_BATTERY 1.9
RTC_HandleTypeDef *rtc;
RTC_TimeTypeDef sTime;
RTC_DateTypeDef sDate;
bool sleepStatus=false;

bool getSleepStatus(){
	return sleepStatus;
}
void setSleppStatus(bool sleep){
	sleepStatus=sleep;
}
void initEvb(ADC_HandleTypeDef *adc){
	evbSense=adc;
}
void initIvb(ADC_HandleTypeDef *adc){
	ivbSense=adc;
}

bool getInputVoltage(float *opADC){
	uint16_t raw=0;
	// Wait for ADC conversion to complete
	HAL_ADC_Start(evbSense);
	if (HAL_ADC_PollForConversion(evbSense, 2000) == HAL_OK)
	{
		// Read ADC value
		raw = HAL_ADC_GetValue(evbSense);
		*opADC = (raw *3.3*REFERANCE_VOLTAGE)/((1 << 12) - 1);
		// Stop ADC conversion
		HAL_ADC_Stop(evbSense);
		return true;
	}
	return false;
}
bool getInternalBattery(float *opADC){
	uint16_t raw=0;
	// Wait for ADC conversion to complete
	HAL_ADC_Start(ivbSense);
	if (HAL_ADC_PollForConversion(ivbSense, 2000) == HAL_OK)
	{
		// Read ADC value
		raw = HAL_ADC_GetValue(ivbSense);
		*opADC = (raw *3.3*INTERNAL_BATTERY)/((1 << 12) - 1);
		// Stop ADC conversion
		HAL_ADC_Stop(evbSense);
		return true;
	}
	return false;
}

bool getIgnition(){
	return LL_GPIO_IsInputPinSet(GPIOA, LL_GPIO_PIN_0);
}

bool getTemperStatus(){
	return LL_GPIO_IsInputPinSet(GPIOB, LL_GPIO_PIN_15);
}
void WAKEUP()
{
	if((__HAL_PWR_GET_FLAG(PWR_WAKEUP_FLAG1) != RESET) )
	   {
			// ADD your code HERE
			SL_WK_GPIO_Int();
		   __HAL_PWR_CLEAR_FLAG(PWR_FLAG_SBF);  // clear the flag
	   	  printc(MinDelay,"WOKEUP BY IGN\r\n");

	   	  __HAL_PWR_CLEAR_FLAG(PWR_WAKEUP_ALL_FLAG);
		    __HAL_RTC_WAKEUPTIMER_CLEAR_FLAG(&hrtc, RTC_FLAG_WUTF);
		  	  /** Disable the WWAKEUP PIN **/
		  	  HAL_PWR_DisableWakeUpPin(PWR_WAKEUP_PIN1);  // disable PA0

		  	  /** Deactivate the RTC wakeup  **/
		  	  HAL_RTCEx_DeactivateWakeUpTimer(rtc);
		  	  wakeUpRoutine();

	   	  }
	   	  else if((__HAL_RTC_WAKEUPTIMER_GET_FLAG(rtc,RTC_FLAG_WUTF) != RESET))
	   	  {
	   		  // ADD YOUR CODE HERE


	   		 __HAL_PWR_CLEAR_FLAG(PWR_FLAG_SBF);  // clear the flag
	   		printc(MinDelay,"WOKEUP BY RTC\r\n");

	   		  __HAL_RTC_WAKEUPTIMER_CLEAR_FLAG(&hrtc, RTC_FLAG_WUTF);
	   		  __HAL_PWR_CLEAR_FLAG(PWR_WAKEUP_ALL_FLAG);
	   	  	  /** Disable the WWAKEUP PIN **/
	   	  	  HAL_PWR_DisableWakeUpPin(PWR_WAKEUP_PIN1);  // disable PA0

	   	  	  /** Deactivate the RTC wakeup  **/
	   	  	  HAL_RTCEx_DeactivateWakeUpTimer(rtc);
	   	  }

	   	  else
	   	  {

	   	  }
    HAL_PWR_EnableWakeUpPin(PWR_WAKEUP_PIN1_HIGH);
//    if (HAL_RTCEx_SetWakeUpTimer_IT(&hrtc, 0x9c40, RTC_WAKEUPCLOCK_RTCCLK_DIV16,0) != HAL_OK)
//    {
//      Error_Handler();
//    }


}
void GO_TO_SLEEP()
{
	  if (LL_GPIO_IsInputPinSet(GPIOA, LL_GPIO_PIN_0) == RESET)
	{
		  // add your code here
		  Sleep_routine();
		  printc(MinDelay,"GOING to STANDBY_Mode\r\n");
		  __HAL_PWR_CLEAR_FLAG(PWR_WAKEUP_FLAG1);
		    LL_GPIO_DeInit(GPIOA);
		     /* Finally enter the standby mode */
		    HAL_PWR_EnterSTANDBYMode();

		       }
}

void SL_WK_GPIO_Int()
{
	  LL_GPIO_InitTypeDef GPIO_InitStruct = {0};
	  LL_AHB2_GRP1_EnableClock(LL_AHB2_GRP1_PERIPH_GPIOA);
	  LL_GPIO_ResetOutputPin(GPIOA, LL_GPIO_PIN_0);
	  LL_GPIO_ResetOutputPin(GPIOA, LL_GPIO_PIN_0);
	  GPIO_InitStruct.Pin = LL_GPIO_PIN_0;
	  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
	  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_LOW;
	  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
	  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
	  LL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}


void initRTC(RTC_HandleTypeDef *hrtc){
	rtc=hrtc;
}
bool setTime(uint8_t hours,uint8_t minute,uint8_t second){
	 clearBuffer((uint8_t*)&sTime, sizeof(sTime));
	 sTime.Hours=hours;
	 sTime.Minutes=minute;
	 sTime.Seconds=second;
	 if (HAL_RTC_SetTime(rtc, &sTime, RTC_FORMAT_BIN) != HAL_OK) {
	 	    // Handle error
	 		return false;
	 }
	 return true;
}
bool setDate(uint8_t date,uint8_t month,uint8_t year){
	 clearBuffer((uint8_t*)&sDate, sizeof(sDate));
	 sDate.Date=date;
	 sDate.Month=month;
	 sDate.Year=year;
	 if (HAL_RTC_SetDate(rtc, &sDate, RTC_FORMAT_BIN) != HAL_OK) {
			return false;
	 }
	 return true;
}
bool getDateTime(char *opDate,char *opTime){
	clearBuffer((uint8_t*)&sTime, sizeof(sTime));
	clearBuffer((uint8_t*)&sDate, sizeof(sDate));
	if(HAL_RTC_GetTime(rtc, &sTime, RTC_FORMAT_BIN)!=HAL_OK){
			return false;
		}
	if(HAL_RTC_GetDate(rtc, &sDate, RTC_FORMAT_BIN)!=HAL_OK){
		return false;
	}

	sprintf(opDate,"%02d%02d20%02d", sDate.Date, sDate.Month, sDate.Year);
	sprintf(opTime,"%02d%02d%02d",sTime.Hours, sTime.Minutes, sTime.Seconds);
	return true;
}


