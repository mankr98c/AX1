
#include "main.h"

typedef void (*pFunction)(void);

unsigned long CP_Address;
//#define Config_Data ((uint32_t)0x08064000) //Sector 50 Full

pFunction Jump_To_Application;


uint64_t CP;

void Application_jump(int GI) {
	if (CP == 3 || CP ==1) {
		printf("Bootloader Function For Location2\n\r");
		void (*app_reset_handler)(
				void) = (void*)(*((volatile uint32_t*) (L2 + 4U)));
		writeF_CP(CP = 2);

		/* Reset the Clock */
		HAL_RCC_DeInit();
		HAL_DeInit();
//	  __set_MSP(*(volatile uint32_t*) 0x081E0000);
		SysTick->CTRL = 0;
		SysTick->LOAD = 0;
		SysTick->VAL = 0;

		/* Jump to application */
		app_reset_handler();    //call the app reset handler
	} else if (CP == 2  ) {
		printf("Bootloader Function For Location3\n\r");

		void (*app_reset_handler)(
				void) = (void*)(*((volatile uint32_t*) (L3 + 4U)));

		writeF_CP(CP = 3);
		printf("Bootloader running into @Location3\n\r");

		/* Reset the Clock */
		HAL_RCC_DeInit();
		HAL_DeInit();
		//	  __set_MSP(*(volatile uint32_t*) 0x081E0000);
		SysTick->CTRL = 0;
		SysTick->LOAD = 0;
		SysTick->VAL = 0;

		/* Jump to application */
		app_reset_handler();
	} else {
		CP = 0;
		printf("Not Updating");
	}
	if (GI == 1) {
		printf("Bootloader Function For Golden Image Location\n\r");

				void (*app_reset_handler)(
						void) = (void*)(*((volatile uint32_t*) (L1 + 4U)));

				writeF_CP(CP = 1);
				/* Reset the Clock */
				HAL_RCC_DeInit();
				HAL_DeInit();
		//	  __set_MSP(*(volatile uint32_t*) 0x081E0000);
				SysTick->CTRL = 0;
				SysTick->LOAD = 0;
				SysTick->VAL = 0;

				/* Jump to application */
				app_reset_handler();    //call the app reset handler


	}
}


