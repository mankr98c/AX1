/*
 * SMS_COTA.h
 *
 *  Created on: May 7, 2024
 *      Author: Manky
 */

#include "main.h"
#include "Flash.h"

#ifndef INC_SMS_COTA_H_
#define INC_SMS_COTA_H_

/************************************************SMS_COTA_STORAGE_SECTOR-181****************************************************/

#define SMS_COTA_SEC								((uint32_t)0x0816A000)
#define MQTT_IP 									((uint32_t)0x0816A010)
#define MQTT_PORT 									((uint32_t)0x0816A020)
#define MQTT_USER									((uint32_t)0x0816A030)
#define MQTT_PSW 									((uint32_t)0x0816A040)
#define MQTT_CERTIFICATE 							((uint32_t)0x0816A050)
#define MQTT_KEY 									((uint32_t)0x0816A060)
#define MQTT_CERTIFICATE_AUTHORITY 					((uint32_t)0x0816A070)
#define FOTA_IP2 									((uint32_t)0x0816A080)
#define FOTA_PORT2 									((uint32_t)0x0816A090)
#define FOTA_Static_Key1 							((uint32_t)0x0816A0A0)
#define FOTA_Static_Key2							((uint32_t)0x0816A0C0)
#define FOTA_Static_Key3							((uint32_t)0x0816A0E0)
#define APN 										((uint32_t)0x0816A100)
#define ION_Sampling								((uint32_t)0x0816A120)
#define NO_OF_Sampling 								((uint32_t)0x0816A130)
#define HARSH_ACC_TH 								((uint32_t)0x0816A140)
#define HARSH_DEACC_TH	 							((uint32_t)0x0816A150)
#define HARSH_CORNERING_TH							((uint32_t)0x0816A160)
#define SENSOR_OFFSET_CAL 							((uint32_t)0x0816A170)
#define USERNAME 									((uint32_t)0x0816A180)
#define PASSWORD		 							((uint32_t)0x0816A190)
#define VECHILE_ID_NUM	 							((uint32_t)0x0816A1A0)
#define ECU_Part_Number 							((uint32_t)0x0816A1B0)
#define ECU_Assembly_Number							((uint32_t)0x0816A1C0)
#define UPDATE_FW_CMD								((uint32_t)0x0816A1D0)

/***********************************************************END_OF_ALLOCATION*****************************************************/

typedef struct {
	char *MIP;
	char *MPORT1;
	char *MUSER;
	char *MPASS;
	char *CERT;
	char *KEY;
	char *CA;
	char *IP2;
	char *IPPORT2;
	char *SKEY1;
	char *SKEY2;
	char *SKEY3;
	char *DAPN;
	char *ION;
	char *NSAM;
	char *HA;
	char *HB;
	char *HC;
	char *ACCOFFSET;
	char *USER;
	char *PSWD;
	char *VIN;
	char *FOTAVER;
} RConfiguration;

bool SET_MIP(char *ip_address);
bool SET_PORT1(char *port);
bool SET_MUSER(char *username);
bool SET_MPASS(char *password);
bool SET_CERT(char *filename);
bool SET_KEY(char *filename);
bool SET_CA(char *filename);
bool SET_IP2(char *address);
bool SET_PORT2(char *value);
bool SET_SKEY1(char *keyValue);
bool SET_SKEY2(char *keyValue);
bool SET_SKEY3(char *keyValue);
bool SET_APN(char *number);
bool SET_ION(char *number);
bool SET_NSAM(char *number);
bool SET_HA(char *number);
bool SET_HB(char *number);
bool SET_HC(char *number);
bool SET_ACCOFFSET(char *number);
bool SET_USER(char *idVal);
bool SET_PASSWORD(char *passwordVal);
bool SET_VIN(char *number);

bool SET_FOTA_UPDATE(char *Version);

bool GET_MIP();
bool GET_PORT1();
bool GET_MUSER(char*);
bool GET_MPASS(char*);
bool GET_CERT(char*);
bool GET_KEY(char*);
bool GET_CA(char*);
bool GET_IP2(char*);
bool GET_PORT2(char*);
bool GET_SKEY1(char*);
bool GET_SKEY2(char*);
bool GET_SKEY3(char*);
bool GET_APN(char*);
bool GET_ION(char*);
bool GET_NSAM(char*);
bool GET_HA(char*);
bool GET_HB(char*);
bool GET_HC(char*);
bool GET_ACCOFFSET(char*);
bool GET_USER(char*);
bool GET_PASSWORD(char*);
bool GET_VIN(char*);
bool SMS_COTA(char *SMSBuff,char *opBuffer);
void getAllConfig();
void Erase_SMSCOTA_SEC();
void Write_CFGFlash (uint32_t WriteLoc, uint64_t *DATA);
bool getUpdateStatus();
void setUpdateStaus(bool upStatus);


#endif /* INC_SMS_COTA_H_ */
